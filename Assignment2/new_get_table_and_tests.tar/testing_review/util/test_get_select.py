import html_util

print '''<html>
<head><title>html_util test output</title></head>
<body>
'''
print 'visible initial selection ' +\
 html_util.get_select('text0',['0','1'],'1') + \
 '<p>' + \
 'empty initial selection ' + html_util.get_select('text1',['','0','1'],'')

print '''
</body>
</html>
'''
