import html_util

print '''<html>
<head>
<title>html_util.get_table() - with border</title>
<style type='text/css'>''' + \
html_util.make_css_borders(1,'my_id_string') + \
'''
</style>
</head>
<body>
''' + \
html_util.get_table([['a','b'],['c','d']],'id="my_id_string"') + \
'''
</body>
</html>
'''
