import html_util

print '''<html>
<head><title>html_util test output</title></head>
<body>
'''

print 'default width ' + html_util.get_text('text0','0') + \
 '<p>' + \
 'explicit width ' + html_util.get_text('text1','1',10)

print '''
</body>
</html>
'''
