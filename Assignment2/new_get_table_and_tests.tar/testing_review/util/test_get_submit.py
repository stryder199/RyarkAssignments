import html_util

print '''<html>
<head><title>html_util test output</title></head>
<body>
'''

print 'enabled ' + html_util.get_submit('submit_a','a') + \
 '<p>' + \
 'disabled ' + html_util.get_submit('submit_b','b',True)

print '''
</body>
</html>
'''
